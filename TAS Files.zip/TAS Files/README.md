# Celeste TAS Inputs
Celeste maingame TAS inputs.

This repository is no longer used for the TAS tools. You can find those at the [EverestInterop repository.](https://github.com/EverestAPI/CelesteTAS-EverestInterop)

You can find the most up-to-date input files here, or download them all [here](https://github.com/EuniverseCat/CelesteTAS/archive/refs/heads/master.zip).
