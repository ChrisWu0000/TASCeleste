[Files have been moved here.](https://github.com/EuniverseCat/CelesteTAS)
